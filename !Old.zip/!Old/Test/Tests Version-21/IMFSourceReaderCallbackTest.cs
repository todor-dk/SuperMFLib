﻿using System;
using System.Text;

using MediaFoundation;
using MediaFoundation.Misc;
using System.Diagnostics;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TestsVersion_21
{
    [TestClass]
    public class IMFSourceReaderCallbackTest
    {
        public void DoTests()
        {
        }
    }
}
