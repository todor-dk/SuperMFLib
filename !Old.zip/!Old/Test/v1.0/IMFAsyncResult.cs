Tested in IMFByteStreamTest.cs
