using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Runtime.InteropServices;

using MediaFoundation;
using MediaFoundation.Misc;
using MediaFoundation.EVR;

namespace Testv10
{
    class IMFContentEnablerTest
    {
        public void DoTests()
        {
            Debug.Assert(false, "Tested in ProtectedPlayback");
        }
    }
}
