using System;
using System.Collections.Generic;
using System.Text;

namespace Testv10
{
    class IMFByteStreamHandlerTest
    {
        // Tested by wavsource
    }
}
