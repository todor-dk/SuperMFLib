Tested in IMFByteStreamTest.cs
