using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;

namespace TestsVersion_10
{
    [TestClass]
    public class IMFByteStreamHandlerTest
    {
        // Tested by wavsource
    }
}
